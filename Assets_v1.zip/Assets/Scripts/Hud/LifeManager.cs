using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LifeManager : MonoBehaviour
{

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
